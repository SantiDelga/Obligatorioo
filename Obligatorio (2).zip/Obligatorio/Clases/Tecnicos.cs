﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Obligatorio.Clases
{
    public class Tecnicos
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int CI { get; set; }
        public string Especialidad { get; set; }
    }
}